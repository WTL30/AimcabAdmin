<?php
  echo $amount=$_POST['total1'];
  echo $partial = $_POST['partial1'];
  echo $phone =$_POST['phone1'] ; 
  $pickup = $_POST['pickup1'] ; 
  $drop= $_POST['drop1'] ; 
  $date= $_POST['date1'] ; 
  $time= $_POST['time1'] ; 
  $car=$_POST['car1'];
  echo $name=$_POST['name'];
  echo $email=$_POST['email'];
  $distance=$_POST['distance1'];
  $bookid = $_POST['bookid1'];
  $new_amount = $_POST['new_amount1'];
  $int=(int)$distance;
  ?>