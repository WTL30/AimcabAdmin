<?php include('upload-script.php'); ?>
<!DOCTYPE html>
<html>
<head></head>
<body>
<div class="upload-form">
<form  method="post" enctype="multipart/form-data">
    <input type="file" name="file_name[]" multiple>
    <input type="submit" value="Upload File" name="submit">
</form>
</div>
</body>
</html>